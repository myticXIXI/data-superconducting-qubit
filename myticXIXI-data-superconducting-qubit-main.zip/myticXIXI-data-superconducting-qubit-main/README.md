# myticXIXI-data-superconducting-qubit
Once the data has been reorganized, it will be uploaded, which will be completed by October 8.
